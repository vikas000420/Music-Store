package com.example.tests;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class MusicStoreSite {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
    driver = new FirefoxDriver();
    baseUrl = "https://localhost:8443/MusicStoreSite/";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testMusicStoreSite() throws Exception {
    driver.get(baseUrl + "/MusicStoreSite/");
    driver.findElement(By.linkText("Home")).click();
    driver.findElement(By.linkText("Johnny Cash Greatest Hits")).click();
    driver.findElement(By.id("AddToCart")).click();
    driver.findElement(By.linkText("Login")).click();
    driver.findElement(By.cssSelector("form.form-signin > #username")).clear();
    driver.findElement(By.cssSelector("form.form-signin > #username")).sendKeys("pi");
    driver.findElement(By.cssSelector("form.form-signin > #password")).clear();
    driver.findElement(By.cssSelector("form.form-signin > #password")).sendKeys("123");
    driver.findElement(By.xpath("(//button[@type='submit'])[2]")).click();
    driver.findElement(By.linkText("1 items")).click();
    driver.findElement(By.xpath("//a[contains(text(),'Continue to\n										Checkout')]")).click();
    driver.findElement(By.id("ccNumber")).clear();
    driver.findElement(By.id("ccNumber")).sendKeys("123123123123");
    driver.findElement(By.id("nameOnCC")).clear();
    driver.findElement(By.id("nameOnCC")).sendKeys("sdfsdf");
    new Select(driver.findElement(By.id("cctype"))).selectByVisibleText("MasterCard");
    driver.findElement(By.id("cccode")).clear();
    driver.findElement(By.id("cccode")).sendKeys("123");
    new Select(driver.findElement(By.id("expmonth"))).selectByVisibleText("March");
    new Select(driver.findElement(By.id("expYear"))).selectByVisibleText("2016");
    driver.findElement(By.xpath("//button[@type='submit']")).click();
    driver.findElement(By.linkText("Logout")).click();
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
